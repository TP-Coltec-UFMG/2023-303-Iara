using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    public float moveSpeed = 5f;
    public float jumpForce = 5f;
    private Rigidbody2D rb;
    public bool position_player;
    private bool podePular = true;
    
    void Start()
    {
        position_player = false;
        rb = GetComponent<Rigidbody2D>();
    }

    void Update()
    {
        Move();
        if (podePular == true){

            Jump();
            podePular = false;

        }
    }

    void Move()
    {
        float direction = Input.GetAxis("Horizontal");
        float moveBy = direction * moveSpeed;
        rb.velocity = new Vector2(moveBy, rb.velocity.y);

    }

    void Jump()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            rb.AddForce(new Vector2(0f, jumpForce), ForceMode2D.Impulse);
        }
    }


    private void OnCollisionStay2D(Collision2D col){
       podePular = true; 
	}

    private void OnTriggerEnter2D(Collider2D outro){
        if(outro.CompareTag("initPlataforms") == true){
            this.position_player = true;
        }
	}


}
