using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GeraPlat : MonoBehaviour
{
    [SerializeField] private GameObject plataforma;
    [SerializeField] public float distancia_plat;
    [SerializeField] private float variacaoDaPosicaoY = -5;
    [SerializeField] private float tempoParaGerar;
    private float cronometro;
    private Vector2 ultima_plat;
    private Player player;
    private bool position;

    private void Awake(){
        this.cronometro = this.tempoParaGerar;
    } 


    void Update()
    {
        ultima_plat = plataforma.transform.position;
        this.cronometro -= Time.deltaTime;

        this.player = GameObject.FindObjectOfType<Player>();
        position = player.position_player;

        if(this.cronometro < 0 && position == false)
        {
            GeneratePlatform();
            this.cronometro = this.tempoParaGerar;
        }

    }

    public void GeneratePlatform()
    {
        ultima_plat = new Vector2(ultima_plat.x + distancia_plat, ultima_plat.y * Random.Range(-variacaoDaPosicaoY, variacaoDaPosicaoY));
        this.transform.Translate(Vector3.up );

        Instantiate(plataforma, ultima_plat, Quaternion.identity); //Cria clones apartir da ultima plataforma

    }

}
