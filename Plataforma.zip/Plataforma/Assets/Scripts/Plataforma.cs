using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Plataforma: MonoBehaviour {
    [SerializeField] private float velocidade = 5f;
    [SerializeField] private float variacaoDaPosicaoY = 1;

    private void Awake(){
        this.transform.Translate(Vector3.up * Random.Range(-variacaoDaPosicaoY, variacaoDaPosicaoY));
    }

    private void Update() {
        this.transform.Translate(Vector3.left * this.velocidade * Time.deltaTime);
    }

    private void OnTriggerEnter2D(Collider2D outro){
       if(outro.CompareTag("Finish") == true){
			this.Destruir();
		}
    }

    private void Destruir(){
        GameObject.Destroy(this.gameObject);
    }
}