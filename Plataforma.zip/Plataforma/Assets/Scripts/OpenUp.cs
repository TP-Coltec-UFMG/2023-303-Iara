﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class OpenUp : MonoBehaviour {

	public Text text_pocoes;
	public int pocoes;
	private bool foiPego = false;
	public int valor;

	// Use this for initialization
	void Start () {
		pocoes = 0;
	}
	
	// Update is called once per frame
	void Update() {
		valor = int.Parse(text_pocoes.text);

		if (foiPego == true){

			text_pocoes.text = (valor + 1).ToString();
			pocoes = int.Parse(text_pocoes.text);
			GameObject.Destroy(this.gameObject);

		}
	}

	private void OnTriggerEnter2D(Collider2D outro){

		foiPego = true;
		
	}
}
