using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlatformGenerator : MonoBehaviour
{
    public GameObject plataforma;
    public float distancia_plat = 3f;
    private Vector2 ultima_plat;
    [SerializeField] public int n_plat = 5;

    void Start()
    {
        
        ultima_plat = plataforma.transform.position;
        for (int i = 0; i < n_plat; i++)
        {
            GeneratePlatform();
        }
    
    }


    public void GeneratePlatform()
    {
        ultima_plat = new Vector2(ultima_plat.x + distancia_plat, ultima_plat.y);
        Instantiate(plataforma, ultima_plat, Quaternion.identity); //Cria clones apartir da ultima plataforma
    }

}
