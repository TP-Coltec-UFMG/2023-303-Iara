using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GeradorPlataforma : MonoBehaviour {
    [SerializeField] private float tempoParaGerar;
    [SerializeField] private GameObject plataforms;
    private float cronometro;

    private void Awake(){
        this.cronometro = this.tempoParaGerar;
    } 
    
    void Update () { 
        //Quando que eu quero gerar? Tempo
        float direction = Input.GetAxis("Horizontal");
        this.cronometro -= Time.deltaTime;
        if(this.cronometro < 0 && direction < 0 || direction > 0 )
        {
            GameObject.Instantiate(this.plataforms, this.transform.position, Quaternion.identity);
            this.cronometro = this.tempoParaGerar;
        }
    }
}   

