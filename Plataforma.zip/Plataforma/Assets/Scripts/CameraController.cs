﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraController : MonoBehaviour {



public Transform target; //para colocarmos nosso personagem como alvo
	void Update(){
	
		if (target.position.x <= -34){

			transform.position = new Vector3(-34, 1, transform.position.z);	

		} 
		else if (target.position.x >= 68){

			transform.position = new Vector3(68, 1, transform.position.z);	

		} 
		
		else {

			transform.position = new Vector3(target.transform.position.x, 1, transform.position.z);

		}
			
	
	}	



}
